package cafe.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.*;
import javax.swing.border.*;

import cafe.bo.nhanVienBo;
import cafe.bo.nhanVienBoJDBC;
import javafx.scene.image.Image;

import java.awt.*;

public class _dangNhap extends JFrame implements ActionListener, KeyListener {

	private JPanel contentPane;
	private JTextField valueUser;
	private JPasswordField valuePass;
	private JButton btnLogin;
	private nhanVienBo nhanVienBo = new nhanVienBoJDBC();;
	public static String online;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					_dangNhap frame = new _dangNhap();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public _dangNhap() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 565, 479);
		setLocationRelativeTo(null);
		//setResizable(false);
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.NORTH);
		panel.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JLabel valueImage = new JLabel("");
		panel.add(valueImage);
		valueImage.setBackground(Color.GRAY);
		valueImage.setIcon(new ImageIcon("C:\\Users\\NHANPC2000\\eclipse-workspace\\MVC_Swing\\image\\cafe.jpg"));
		
		JPanel panel_1 = new JPanel();
		FlowLayout flowLayout_1 = (FlowLayout) panel_1.getLayout();
		contentPane.add(panel_1, BorderLayout.CENTER);
		
		JLabel textUser = new JLabel("Tài khoản");
		panel_1.add(textUser);
		textUser.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		valueUser = new JTextField();
		panel_1.add(valueUser);
		valueUser.setText("admin");
		valueUser.setFont(new Font("Tahoma", Font.PLAIN, 15));
		valueUser.setColumns(10);
		
		JLabel textPass = new JLabel("Mật khẩu");
		panel_1.add(textPass);
		textPass.setFont(new Font("Tahoma", Font.PLAIN, 14));
		
		valuePass = new JPasswordField();
		panel_1.add(valuePass);
		valuePass.setFont(new Font("Tahoma", Font.PLAIN, 15));
		valuePass.setColumns(10);
		
		btnLogin = new JButton("Truy cập");
		panel_1.add(btnLogin);
		btnLogin.setFont(new Font("Tahoma", Font.PLAIN, 16));
		
		btnLogin.addActionListener(this);
		
		
		btnLogin.addKeyListener(this);
		valuePass.addKeyListener(this);
		valueUser.addKeyListener(this);
		
		JPanel panel_2 = new JPanel();
		contentPane.add(panel_2, BorderLayout.SOUTH);
		panel_2.setLayout(new BoxLayout(panel_2, BoxLayout.X_AXIS));
		
		JPanel panel_4 = new JPanel();
		FlowLayout flowLayout = (FlowLayout) panel_4.getLayout();
		flowLayout.setAlignment(FlowLayout.RIGHT);
		panel_2.add(panel_4);
		
		JLabel valueVersion = new JLabel("Version: 1.0");
		valueVersion.setFont(new Font("Tahoma", Font.PLAIN, 15));
		panel_4.add(valueVersion);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == btnLogin) {
			login();
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_ENTER) {
			login();
		}		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	public void login() {
		try {
			if(nhanVienBo.login(this.valueUser.getText(), String.valueOf(this.valuePass.getPassword()))) {
				_manHinhChinh _manHinhChinh = new _manHinhChinh(this.valueUser.getText());
				this.dispose();
			}else {
				JOptionPane.showMessageDialog(null, "Thất bại");
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Error 404 - Exit");
		}
	}
	
	
	
}
