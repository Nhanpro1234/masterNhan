package cafe.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;

import com.sun.glass.events.KeyEvent;

import cafe.bo.nhanVienBoJDBC;
import cafe.comp.head2_heThong;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.Color;

public class _doiMatKhau extends JFrame implements ActionListener, KeyListener {

	private JPanel contentPane;
	private JLabel textUser;
	private JLabel textPassNew;
	private JLabel textPassOld;
	private JLabel textPassReNew;
	private JTextField valueUser;
	private JPasswordField valuePassOld;
	private JPasswordField valueRePassNew;
	private JPasswordField valuePassNew;
	private JButton btnHuy;
	private JButton btnDongY;
	private nhanVienBoJDBC nhanVienBo = new nhanVienBoJDBC();
	
	public _doiMatKhau(String user) {
		//setAlwaysOnTop(true);
		setTitle("Đổi mật khẩu");
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 363, 247);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(135, 206, 250));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(5, 6, 0, 0));
		
		textUser = new JLabel("Tài khoản");
		textUser.setFont(new Font("Tahoma", Font.PLAIN, 14));
		contentPane.add(textUser);
		
		valueUser = new JTextField(user);
		valueUser.setEditable(false);
		valueUser.setFont(new Font("Tahoma", Font.PLAIN, 14));
		contentPane.add(valueUser);
		valueUser.setColumns(10);
		
		textPassOld = new JLabel("Mật khẩu cũ ( * )");
		textPassOld.setFont(new Font("Tahoma", Font.PLAIN, 14));
		contentPane.add(textPassOld);
		
		valuePassOld = new JPasswordField();
		valuePassOld.requestFocus();
		valuePassOld.setFont(new Font("Tahoma", Font.PLAIN, 14));
		contentPane.add(valuePassOld);
		valuePassOld.setColumns(10);
		
		textPassNew = new JLabel("Mật khẩu mới ( * )");
		textPassNew.setFont(new Font("Tahoma", Font.PLAIN, 14));
		contentPane.add(textPassNew);
		
		valuePassNew = new JPasswordField();
		valuePassNew.setFont(new Font("Tahoma", Font.PLAIN, 14));
		valuePassNew.setColumns(10);
		contentPane.add(valuePassNew);
		
		textPassReNew = new JLabel("Nhập lại mật khẩu mới ( * )");
		textPassReNew.setFont(new Font("Tahoma", Font.PLAIN, 14));
		contentPane.add(textPassReNew);
		
		valueRePassNew = new JPasswordField();
		valueRePassNew.setFont(new Font("Tahoma", Font.PLAIN, 14));
		contentPane.add(valueRePassNew);
		valueRePassNew.setColumns(10);
		
		btnHuy = new JButton("Hủy bỏ");
		btnHuy.setIcon(new ImageIcon("image\\cancel.png"));
		btnHuy.setFont(new Font("Tahoma", Font.PLAIN, 14));
		contentPane.add(btnHuy);
		
		btnDongY = new JButton("Đồng ý");
		btnDongY.setIcon(new ImageIcon("image\\confirm.png"));
		btnDongY.setFont(new Font("Tahoma", Font.PLAIN, 14));
		contentPane.add(btnDongY);
		
		btnHuy.addActionListener(this);
		btnDongY.addActionListener(this);
		
		valueRePassNew.addKeyListener(this);
		valuePassNew.addKeyListener(this);
		valuePassOld.addKeyListener(this);
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == btnHuy) {
			dispose();
		}
		
		if(e.getSource() == btnDongY){
			changePass();
		}
	}
	
	
	public void changePass() {
		if(!valueUser.getText().equals("")) {
			if(String.valueOf(valueRePassNew.getPassword()).equals(String.valueOf(valuePassNew.getPassword()))) {
				if(nhanVienBo.login(valueUser.getText(), String.valueOf(valuePassOld.getPassword()))) {
					if(nhanVienBo.updatePass(valueUser.getText(), String.valueOf(valuePassNew.getPassword()))) {
						JOptionPane.showMessageDialog(null, "Thành công");
					}else {
						JOptionPane.showMessageDialog(null, "Thất bại", "Error", JOptionPane.ERROR_MESSAGE);
					}
				}else {
					JOptionPane.showMessageDialog(null, "Mật khẩu cũ không đúng", "Error", JOptionPane.ERROR_MESSAGE);
				}
			}else {
				JOptionPane.showMessageDialog(null, "Mật khẩu nhập lại không đúng", "Error", JOptionPane.ERROR_MESSAGE);
			}
		}else{
			JOptionPane.showMessageDialog(null, "Lỗi user trống", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}

	@Override
	public void keyTyped(java.awt.event.KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(java.awt.event.KeyEvent e) {
		if(e.getKeyCode() == KeyEvent.VK_ENTER) {
			changePass();
		}
	}

	@Override
	public void keyReleased(java.awt.event.KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
