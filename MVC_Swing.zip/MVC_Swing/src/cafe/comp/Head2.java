package cafe.comp;

import java.awt.CardLayout;

import javax.swing.JPanel;

public class Head2 extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Head2() {
		setLayout(new CardLayout());
	}

}
