package cafe.comp;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.SystemColor;

import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import com.toedter.calendar.JDateChooser;

import cafe.view._manHinhChinh;

import java.awt.FlowLayout;
import javax.swing.BoxLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.Color;
import javax.swing.UIManager;

public class head2_macDinh extends JPanel {

	private JPanel macDinh;
	private JPanel macDinh1;
	private JLabel lblNewLabel;
	private JPanel macDinh2;
	private JPanel macDinh3;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JPanel macDinh2_1;
	private JPanel macDinh2_2;
	private JLabel lblNewLabel_3;
	private JDateChooser valueTuNgay;
	private JLabel lblNewLabel_4;
	private JDateChooser valueNgayDen;
	private JLabel lblNewLabel_5;
	private JComboBox valueKhachHang;
	private JRadioButton valueTiengAnh;
	private JRadioButton valueTiengViet;
	private JCheckBox valueXemTruoc;
	private JComboBox valueBangGia;
	private JComboBox valueThuNgan;
	private JComboBox valueNhanVien;

	private String user;
	private JPanel macDinh3_1;
	private JLabel label;
	/**
	 * Create the panel.
	 */
	public head2_macDinh(String user, _manHinhChinh _manHinhChinh) {
		setBackground(SystemColor.activeCaption);
		setLayout(new GridLayout(1, 3, 0, 0));
		this.user = user;
		
		macDinh1 = new JPanel();
		macDinh1.setBorder(new TitledBorder(null, "Mặc định", TitledBorder.LEADING, TitledBorder.TOP, null, SystemColor.desktop));
		macDinh1.setBackground(SystemColor.activeCaption);
		add(macDinh1);
		macDinh1.setLayout(new GridLayout(3, 2, 0, 0));

		lblNewLabel = new JLabel("BẢNG GIÁ");
		macDinh1.add(lblNewLabel);
		lblNewLabel.setBackground(SystemColor.activeCaption);

		valueBangGia = new JComboBox();
		macDinh1.add(valueBangGia);
		valueBangGia.setBackground(SystemColor.activeCaption);

		lblNewLabel_2 = new JLabel("NHÂN VIÊN");
		macDinh1.add(lblNewLabel_2);
		lblNewLabel_2.setBackground(SystemColor.activeCaption);

		valueNhanVien = new JComboBox();
		macDinh1.add(valueNhanVien);
		valueNhanVien.setBackground(SystemColor.activeCaption);

		lblNewLabel_1 = new JLabel("THU NGÂN");
		macDinh1.add(lblNewLabel_1);
		lblNewLabel_1.setBackground(SystemColor.activeCaption);

		valueThuNgan = new JComboBox();
		macDinh1.add(valueThuNgan);
		valueThuNgan.setBackground(SystemColor.activeCaption);

		macDinh2 = new JPanel();
		macDinh2.setBorder(new TitledBorder(null, "Báo cáo", TitledBorder.LEADING, TitledBorder.TOP, null, SystemColor.desktop));
		macDinh2.setBackground(SystemColor.activeCaption);
		add(macDinh2);
		macDinh2.setLayout(new GridLayout(2, 0, 0, 0));

		macDinh2_1 = new JPanel();
		macDinh2_1.setBackground(SystemColor.activeCaption);
		macDinh2.add(macDinh2_1);

		lblNewLabel_3 = new JLabel("TỪ NGÀY");
		lblNewLabel_3.setBackground(SystemColor.activeCaption);

		valueTuNgay = new JDateChooser();
		valueTuNgay.setBackground(SystemColor.activeCaption);

		lblNewLabel_4 = new JLabel("ĐẾN NGÀY");
		lblNewLabel_4.setBackground(SystemColor.activeCaption);

		valueNgayDen = new JDateChooser();
		valueNgayDen.setBackground(SystemColor.activeCaption);
		macDinh2_1.setLayout(new BoxLayout(macDinh2_1, BoxLayout.X_AXIS));
		macDinh2_1.add(lblNewLabel_3);
		macDinh2_1.add(valueTuNgay);
		macDinh2_1.add(lblNewLabel_4);
		macDinh2_1.add(valueNgayDen);

		macDinh2_2 = new JPanel();
		macDinh2_2.setBackground(SystemColor.activeCaption);
		macDinh2.add(macDinh2_2);
		macDinh2_2.setLayout(new BoxLayout(macDinh2_2, BoxLayout.X_AXIS));

		lblNewLabel_5 = new JLabel("KHÁCH HÀNG");
		lblNewLabel_5.setBackground(SystemColor.activeCaption);
		macDinh2_2.add(lblNewLabel_5);

		valueKhachHang = new JComboBox();
		valueKhachHang.setBackground(SystemColor.activeCaption);
		macDinh2_2.add(valueKhachHang);

		macDinh3 = new JPanel();
		macDinh3.setBackground(SystemColor.activeCaption);
		add(macDinh3);

		ButtonGroup groupLangue = new ButtonGroup();
		macDinh3.setLayout(new GridLayout(0, 1, 0, 0));

		macDinh3_1 = new JPanel();
		macDinh3_1.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "In hóa đơn", TitledBorder.LEADING, TitledBorder.TOP, null, Color.BLACK));
		macDinh3_1.setBackground(SystemColor.activeCaption);
		macDinh3.add(macDinh3_1);
		macDinh3_1.setLayout(new GridLayout(0, 2, 0, 0));
		valueTiengViet = new JRadioButton("TIẾNG VIỆT");
		macDinh3_1.add(valueTiengViet);
		valueTiengViet.setBackground(SystemColor.activeCaption);
		groupLangue.add(valueTiengViet);

		valueTiengAnh = new JRadioButton("TIẾNG ANH");
		macDinh3_1.add(valueTiengAnh);
		valueTiengAnh.setBackground(SystemColor.activeCaption);
		groupLangue.add(valueTiengAnh);

		valueXemTruoc = new JCheckBox("XEM TRƯỚC HÓA ĐƠN");
		macDinh3_1.add(valueXemTruoc);
		valueXemTruoc.setBackground(SystemColor.activeCaption);

		label = new JLabel("");
		macDinh3_1.add(label);
	}

}
