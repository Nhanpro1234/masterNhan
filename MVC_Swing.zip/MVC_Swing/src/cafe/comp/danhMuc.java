package cafe.comp;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.BoxLayout;
import java.awt.Choice;
import javax.swing.JCheckBoxMenuItem;
import java.awt.FlowLayout;
import java.awt.Component;
import javax.swing.Box;
import javax.swing.JMenu;
import javax.swing.JOptionPane;
import javax.swing.JList;
import javax.swing.JComboBox;
import java.awt.Color;
import java.awt.CardLayout;
import java.awt.BorderLayout;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import cafe.bean.khuVuc;
import cafe.bo.khuVucBo;
import cafe.bo.khuVucBoJDBC;
import cafe.bo.nhanVienBo;
import cafe.view._manHinhChinh;

import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import javax.swing.DefaultComboBoxModel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import java.awt.SystemColor;
import javax.swing.JSplitPane;
import javax.swing.AbstractListModel;
import java.awt.List;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Vector;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;

public class danhMuc extends JPanel implements ActionListener, MouseListener {
	private JPanel danhMuc1;
	private JPanel danhMuc2;
	private JPanel danhMjuc1_1;
	private JComboBox timKiemDanhMuc;
	private JPanel danhMuc1_2;
	private JPanel danhMuc2_1;
	private JLabel lblNewLabel;
	private JPanel danhMuc2_1_2;
	private JButton add;
	private JButton edit;
	private JButton delete;
	private JButton reload;
	private JPanel danhMuc2_1_1;
	private JSplitPane splitDanhMuc;
	private JPanel danhMuc2_2;
	private DefaultTableModel dm;
	private List list;
	private JPanel danhMuc2_1_1_1;
	private JPanel danhMuc2_1_1_2;
	private JButton close;
	private _manHinhChinh _manHinhChinh;
	private JTable table;
	private JCheckBox chckbxNewCheckBox;
	private khuVucBo khuVucBo;
	
	private int CheckStatus; // 0 = khu vực, 1 b

	private danhMucKhuVuc danhMucKhuVuc;
	private danhMucSanPhongBan danhMucSanPhongBan;
	
	/**
	 * Create the panel.
	 */
	public danhMuc(_manHinhChinh _manHinhChinh) {
		this._manHinhChinh = _manHinhChinh;
		setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		
		splitDanhMuc = new JSplitPane();
		splitDanhMuc.setDividerLocation(250);
		add(splitDanhMuc);
		
		danhMuc1 = new JPanel();
		splitDanhMuc.setLeftComponent(danhMuc1);
		danhMuc1.setBackground(SystemColor.inactiveCaption);
		danhMuc1.setLayout(new BorderLayout(0, 0));
		
		danhMjuc1_1 = new JPanel();
		danhMjuc1_1.setBackground(SystemColor.inactiveCaption);
		danhMuc1.add(danhMjuc1_1, BorderLayout.NORTH);
		danhMjuc1_1.setLayout(new BoxLayout(danhMjuc1_1, BoxLayout.X_AXIS));
		
		timKiemDanhMuc = new JComboBox();
		timKiemDanhMuc.setFont(new Font("Tahoma", Font.PLAIN, 15));
		timKiemDanhMuc.setModel(new DefaultComboBoxModel(new String[] {"Bàn phòng","Sản phẩm"}));
		danhMjuc1_1.add(timKiemDanhMuc);
		
		danhMuc1_2 = new JPanel();
		danhMuc1_2.setBackground(SystemColor.inactiveCaption);
		danhMuc1.add(danhMuc1_2, BorderLayout.CENTER);
		danhMuc1_2.setLayout(new BoxLayout(danhMuc1_2, BoxLayout.Y_AXIS));
		
		list = new List();
		list.add("Khu vực");
		list.add("Bàn phòng");
		list.setFont(new Font("Dialog", Font.PLAIN, 15));
		danhMuc1_2.add(list);
		
		
		// ándasd
		
		list.addMouseListener(this);
		
		/*danhMucKhuVuc = new danhMucKhuVuc(_manHinhChinh);*/
		splitDanhMuc.setRightComponent(new JPanel());
		
	}

	public JSplitPane getSplitDanhMuc() {
		return splitDanhMuc;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if(e.getSource() == list) {
			if(list.getSelectedItem().equals("Khu vực")) {
				danhMucKhuVuc = new danhMucKhuVuc(this);
				splitDanhMuc.setRightComponent(danhMucKhuVuc);
			}
			if(list.getSelectedItem().equals("Bàn phòng")) {
				danhMucSanPhongBan = new danhMucSanPhongBan(this);
				splitDanhMuc.setRightComponent(danhMucSanPhongBan);
			}
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	

}
