package cafe.comp;

import java.awt.CardLayout;

import javax.swing.JPanel;

public class head2 extends JPanel {

	private JPanel mainCha;
	
	
	public head2() {
		setLayout(new CardLayout());
	}

}
