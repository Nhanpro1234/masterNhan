package cafe.bo;

import java.util.ArrayList;

import cafe.bean.nhanVien;
import cafe.dao.nhanVienDao;
import cafe.dao.nhanVienDaoJDBC;

public class nhanVienBoJDBC implements nhanVienBo {
	private nhanVienDaoJDBC nhanVienDaoJDBC;
	
	public nhanVienBoJDBC() {
		nhanVienDaoJDBC = new nhanVienDaoJDBC();
	}
	
	@Override
	public boolean login(String taiKhoan, String matKhau) {
		if(taiKhoan == null) {
			return false;
		}
		boolean result = nhanVienDaoJDBC.login(taiKhoan, matKhau);
		return result;
	}

	@Override
	public boolean checkUser(String taiKhoan) {
		if(taiKhoan == null) {
			return false;
		}
		boolean result = nhanVienDaoJDBC.checkUSer(taiKhoan);
		return result;
	}
	
	@Override
	public boolean checkUserAdmin() {
		boolean result = nhanVienDaoJDBC.checkUSer("admin");
		if(!result) {
			addUserAdmin();
		}
		return result;
	}
	

	@Override
	public boolean addUserAdmin() {
		nhanVienDaoJDBC.insert(new nhanVien("NV_1", 0, null, null, null, null, 1, 1, "admin", ""));
		return false;
	}

	@Override
	public boolean update(String maNV, String nameCol, String valueNew) {
		return nhanVienDaoJDBC.update(maNV, nameCol, valueNew);
	}

	@Override
	public boolean updatePass(String taiKhoan, String valueNew) {
		return nhanVienDaoJDBC.updatePass(taiKhoan, valueNew);
	}
	
}
