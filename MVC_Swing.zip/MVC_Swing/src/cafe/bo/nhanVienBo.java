package cafe.bo;

import java.util.ArrayList;

public interface nhanVienBo {
	public boolean login(String taiKhoan, String matKhau);
	public boolean checkUser(String taiKhoan);
	public boolean checkUserAdmin();
	public boolean addUserAdmin();
	public boolean update(String maNV, String nameCol, String valueNew);
	public boolean updatePass(String taiKhoan, String valueNew);
}
