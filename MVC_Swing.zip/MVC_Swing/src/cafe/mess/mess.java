package cafe.mess;

public class mess {
	public static final String ERROR_DATABASE = "LỖI KẾT NỐI DỮ LIỆU";
	public static final String ERROR_LOGIN_FALSE = "TÀI KHOẢN HOẶC MẬT KHẨU SAI";
	public static final String ERROR_EXCEPTION = "LỖI EXCEPTION";
	
	
}
