package cafe.dao;

import java.util.ArrayList;

import cafe.bean.nhanVien;

public interface nhanVienDao {
	public boolean insert(nhanVien data);
	public String getLast();
	public boolean update(String maNV, String nameCol, String valueNew);
	public boolean updatePass(String taiKhoan, String valueNew);
	public boolean isId(String value);
	public boolean delete(String col, String value);
	public ArrayList<nhanVien> get();
	public boolean login(String taiKhoan, String matKhau);
	public boolean checkUSer(String taiKhoan);
}
