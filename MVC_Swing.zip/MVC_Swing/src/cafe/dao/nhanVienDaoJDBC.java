package cafe.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import cafe.bean.nhanVien;



public class nhanVienDaoJDBC implements nhanVienDao {
	
	public nhanVienDaoJDBC() {
		
	}
	
	@Override
	public boolean insert(nhanVien data) {
		String maNV = null;
		dataBase dataBase = new dataBase();
		Connection conn = dataBase.conn();
		if(conn == null) {
			return false;
		}
		String last = getLast();
		if(last.equals("null")) {
			maNV = "NV_1";
		}else {
			String[] split = last.split("_");
			maNV = "NV_" + (Integer.parseInt(split[1]) + 1);
		}
		
		String sql = "INSERT INTO `nhan_vien` VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		try {
			PreparedStatement s = conn.prepareStatement(sql);
			s.setString(1, maNV);
			s.setInt(2, data.getMaBP());
			s.setString(3, data.getHoTen());
			s.setString(4, data.getDiaChi());
			s.setString(5, data.getDienThoai());
			s.setString(6, data.getMaSoThue());
			s.setInt(7, data.getIsKeToan());
			s.setInt(8, data.getIsThuNgan());
			s.setString(9, data.getTaiKhoan());
			s.setString(10, data.getMatKhau());
			
			int check = s.executeUpdate();
			if(check > 0) {
				return true;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			dataBase.disconect(conn);
		}
		
		return false;
	}
	
	@Override
	public String getLast() {
		dataBase dataBase = new dataBase();
		Connection conn = dataBase.conn();
		if(conn == null) {
			return "Lỗi kết nối >> SQL <<";
		}
		
		String sql = "SELECT maNV FROM `nhan_vien` ORDER BY maNV DESC LIMIT 1";
		try {
			PreparedStatement s = conn.prepareStatement(sql);
			ResultSet r = s.executeQuery();
			while(r.next()) {
				return r.getString("maNV");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "Lỗi truy vấn";
		} finally {
			dataBase.disconect(conn);
		}
		
		return "null";
	}
	
	@Override
	public boolean update(String maNV, String nameCol, String valueNew) {
		if(!isId(maNV)) {
			return false;
		}
		dataBase dataBase = new dataBase();
		Connection conn = dataBase.conn();
		if(conn == null){
			return false;
		}
		String sql = "UPDATE `nhan_vien` SET `" + nameCol + "` = ? WHERE maNV = ?";
		try {
			PreparedStatement s = conn.prepareStatement(sql);
			s.setString(1, valueNew);
			s.setString(2, maNV);
			
			int check = s.executeUpdate();
			if(check > 0) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}finally {
			dataBase.disconect(conn);
		}
		return false;
	}
	
	@Override
	public boolean isId(String value) {
		dataBase dataBase = new dataBase();
		Connection conn = dataBase.conn();
		if(conn == null){
			return false;
		}
		String sql = "SELECT * FROM `nhan_vien` Where `maNV` = ?";
		try {
			PreparedStatement s = conn.prepareStatement(sql);
			s.setString(1, value);
			ResultSet result = s.executeQuery();
			if(result.next()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			dataBase.disconect(conn);
		}
		return false;
	}
	
	@Override
	public boolean delete(String col, String value) {
		dataBase dataBase = new dataBase();
		Connection conn = dataBase.conn();
		if(conn == null){
			return false;
		}
		String sql = "DELETE FROM `nhan_vien` Where `" + col + "` = ?";
		try {
			PreparedStatement s = conn.prepareStatement(sql);
			s.setString(1, value);
			
			int check = s.executeUpdate();
			if(check > 0) {
				return true;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			dataBase.disconect(conn);
		}
		return false;
	}
	
	@Override
	public ArrayList<nhanVien> get(){
		ArrayList<nhanVien> ress = new ArrayList<>();
		
		dataBase dataBase = new dataBase();
		Connection conn = dataBase.conn();
		if(conn == null){
			return ress;
		}
		
		String sql = "SELECT * FROM `nhan_vien`";

		try {
			PreparedStatement s = conn.prepareStatement(sql);
			ResultSet r = s.executeQuery();
			while(r.next()) {
				ress.add(new nhanVien(r.getString("maNV"), r.getInt("maBP"),r.getString("hoTen"),r.getString("diachi"),r.getString("dienThoai"),r.getString("maSoThue"), r.getInt("isKeToan"),r.getInt("isThuNgan"),r.getString("taiKhoan"),r.getString("matKhau")));
			}
			return ress;
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			dataBase.disconect(conn);
		}
		return ress;
	}

	@Override
	public boolean login(String taiKhoan, String matKhau) {
		dataBase dataBase = new dataBase();
		Connection conn = dataBase.conn();
		if(conn == null){
			return false;
		}
		String sql = "SELECT * FROM `nhan_vien` Where `taiKhoan` = ? and `matKhau` = ?";
		
		if(matKhau.equals("")) {
			matKhau = "";
		}
		
		try {
			PreparedStatement s = conn.prepareStatement(sql);
			s.setString(1, taiKhoan);
			s.setString(2, matKhau);
			ResultSet result = s.executeQuery();
			if(result.next()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			dataBase.disconect(conn);
		}
		return false;
	}

	@Override
	public boolean checkUSer(String taiKhoan) {
		dataBase dataBase = new dataBase();
		Connection conn = dataBase.conn();
		if(conn == null){
			return false;
		}
		String sql = "SELECT * FROM `nhan_vien` Where `taiKhoan` = ?";
		try {
			PreparedStatement s = conn.prepareStatement(sql);
			s.setString(1, taiKhoan);
			ResultSet result = s.executeQuery();
			if(result.next()) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			dataBase.disconect(conn);
		}
		return false;
	}
	
	@Override
	public boolean updatePass(String taiKhoan, String valueNew) {
		dataBase dataBase = new dataBase();
		Connection conn = dataBase.conn();
		if(conn == null){
			return false;
		}
		String sql = "UPDATE `nhan_vien` SET `matKhau` = ? WHERE taiKhoan = ?";
		try {
			PreparedStatement s = conn.prepareStatement(sql);
			s.setString(1, valueNew);
			s.setString(2, taiKhoan);
			
			int check = s.executeUpdate();
			if(check > 0) {
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}finally {
			dataBase.disconect(conn);
		}
		return false;
	}
	
	
}
